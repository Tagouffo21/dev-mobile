import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-network',
  templateUrl: './no-network.page.html',
  styleUrls: ['./no-network.page.scss'],
})
export class NoNetworkPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

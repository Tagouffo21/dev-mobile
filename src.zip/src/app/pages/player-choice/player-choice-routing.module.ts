import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PlayerChoicePage } from './player-choice.page';


@NgModule({
  imports: [],
  exports: [],
})
export class PlayerChoicePageRoutingModule {}

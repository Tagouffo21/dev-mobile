import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PlayConfigPageRoutingModule } from './play-config-routing.module';

import { PlayConfigPage } from './play-config.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PlayConfigPageRoutingModule
  ],
  declarations: [PlayConfigPage]
})
export class PlayConfigPageModule {}

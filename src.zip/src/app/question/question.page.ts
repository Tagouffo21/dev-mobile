import { Component, Injectable, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';
import { Router } from '@angular/router';


interface LoginResponse {
  id: number,
  Libelle_question: string,
  is_active: number,
  created_at: string,
  updated_at: string,
  niveaux_id: number,
  categories_id: number
}

@Component({
  selector: 'app-question',
  templateUrl: './question.page.html',
  styleUrls: ['./question.page.scss'],
})


@Injectable()

export class QuestionPage implements OnInit {
  base_url:string = "https://mboaculture.ossu-technology.com";
  constructor(private api:ApiService,private route:Router) { }

  ngOnInit() {


  }

  onSubmit() {
  
  }
  
}


